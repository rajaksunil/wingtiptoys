﻿using System.Web.UI;

namespace WingtipToys.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}